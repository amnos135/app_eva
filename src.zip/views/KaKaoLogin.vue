<template>
  <div>
    <a id="custom-login-btn" @click="kakaoLogin()">
        <img src="//k.kakaocdn.net/14/dn/btqCn0WEmI3/nijroPfbpCa4at5EIsjyf0/o.jpg
" width="222" alt="">
    </a>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>