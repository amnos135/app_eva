<template>
<Header />
<div id="wrap">
            <div>
                <center>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3169.455920414688!2d126.9198448221143!3d37.402697323655964!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x357b613383382325%3A0x3abf2b7399053b96!2z7Iqk7YOA67KF7IqkIOyViOyWkeyXrVLsoJA!5e0!3m2!1sko!2skr!4v1658294463847!5m2!1sko!2skr" width="90%" height="700" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </center>
                <span class="search"><a href="#none">
                    <img src="./img/re.png" alt="되돌리기"> 현 위치에서 검색</a></span>
            </div>
            <div id="category">
                <ul>
                    <li><img class="cate" src="./img/cate.png" alt="category"></li>
                    <li class="tab"><a href="#none">거리 순 <img src="./img/cate2.png" alt=""></a></li>
                    <li><a href="#none"> 영업 중<img class="cate3" src="./img/cate2.png" alt=""></a></li>
                    <li><a href="#none">별점 순<img src="./img/cate2.png" alt=""></a></li>
                    <li><a href="#none">대형카페<img src="./img/cate2.png" alt=""></a></li>
                    <li><a href="#none">조각케익<img src="./img/cate2.png" alt=""></a></li>
                    
                </ul>
            
                <div class="list">
                    <ul>
                        <li><img src="./img/list1.png" alt="yogerpresso" class="cafe">
                            <a href="#none">
                            <ul>
                                <li><h2>Yogerpresso</h2></li>
                                    <li>현재 위치에서 5m </li>
                                    <li>
                                        <img src="./img/Star1.png" alt="별점">
                                        <img src="./img/Star1.png" alt="별점">
                                        <img src="./img/Star1.png" alt="별점">
                                        <img src="./img/Star1.png" alt="별점">
                                        <img src="./img/Star2.png" alt="별점"> 
                                    </li>
                                        <li>#요거프레소 #딸기요거트 #아이스아메리카노 #과일빙수</li>
                            </ul></a>
                        </li>
                        <li><img src="./img/list2.png" alt="starbucks" class="cafe">
                            <a href="#none">
                            <ul>
                                <li><h2>Starbucks</h2></li>
                                    <li>현재 위치에서 5m </li>
                                    <li>
                                        <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.5.png" alt="별점">  
                                    </li>
                                        <li>#스타벅스 #아메리카노 #조각케익 #시즌음료  #텀블러</li>
                            </ul></a>
                        </li>
                        <li><img src="./img/list3.png" alt="Ediya" class="cafe">
                            <a href="#none">
                            <ul>
                                <li><h2>Ediya Coffe</h2></li>
                                    <li>현재 위치에서 5m </li>
                                    <li>
                                        <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star2.png" alt="별점">
                                <img src="./img/Star2.png" alt="별점"> 
                                    </li>
                                        <li>#이디야 #아이스아메리카노 #디저트 #가성비</li>
                            </ul></a>
                        </li>
                        <li><img src="./img/list4.png" alt="Ediya" class="cafe">
                            <a href="#none">
                            <ul>
                                <li><h2>A Twosome Place</h2></li>
                                    <li>현재 위치에서 5m </li>
                                    <li>
                                        <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.5.png" alt="별점">
                                <img src="./img/Star2.png" alt="별점"> 
                                    </li>
                                        <li>#투썸플레이스 #디저트 #조각케익 #넓은카페 </li>
                            </ul></a>
                        </li>
                        <li><img src="./img/list5.png" alt="Ediya" class="cafe">
                            <a href="#none">
                            <ul>
                                <li><h2>Mega Coffe</h2></li>
                                    <li>현재 위치에서 5m </li>
                                    <li>
                                        <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star2.png" alt="별점"> 
                                    </li>
                                        <li>#메가커피 #아이스아메리카노 #프라페  #가성비</li>
                            </ul></a>
                        </li>
                        <li><img src="./img/list6.png" alt="dessert39" class="cafe">
                            <a href="#none">
                            <ul>
                                <li><h2>Dessert 39</h2></li>
                                    <li>현재 위치에서 5m </li>
                                    <li>
                                        <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.png" alt="별점">
                                <img src="./img/Star1.5.png" alt="별점">  
                                    </li>
                                        <li>#디저트 #빙수 #조각케익 #가성비  #대용량</li>
                            </ul></a>
                        </li>
                    </ul>
                </div>
            
            </div>
    </div>
<Footer />  
</template>

<script>
import Header from '../layouts/Header.vue';
import Footer from '../layouts/Footer.vue';

export default {
  components: { Header, Footer },
  
} 

</script>

<style scoped>
@font-face {
    font-family: 'GowunDodum-Regular','Noto Sans KR', sans-serif;
    src: url('https://cdn.jsdelivr.net/gh/projectnoonnu/noonfonts_2108@1.1/GowunDodum-Regular.woff') format('woff');
    font-weight: normal;
    font-style: normal;
}
h2{
    font-weight: bold;
}
ul,li{list-style: none;}
a{text-decoration: none; color: #333;}
#wrap{
    
    width: 100%;
    margin: 0 auto;
    position: relative;
    box-sizing: border-box;
    min-height: 1507px;
    text-align: left;
}
/* header */
header{
    position: fixed;
    width: 100%;
    z-index: 10; 
}


    iframe{
        float: center;
        z-index: 1;
        width: 100%;
    }
    span.search{
         top: 80px;
         width: auto;
        height: 40px;
        background: #ffffff;
         border: 2px solid #065F44;
        border-radius: 25px;
        padding: 3px 3%;
        font-size: 1.3rem;
        z-index: 5; 
         position: absolute; 
         left: 50%;
          transform: translateX(-50%); 

    }
    span.search img{
        width: 20px;
        margin-top: -4px;
    }
    
#category{
    position: absolute;
    top: 680px;
    width: 100%;
    height: 1500px;
    background-color: rgb(255, 255, 255);
    overflow: hidden;
    border-radius: 50px 50px 0 0;
    margin: 0 auto;
    z-index: 2;
}
#category > ul{
    margin-top: 35px;
    margin-left: -25px;
    width: 1000px;
    /* height: auto; */
}
#category> ul>li{
    display: flex;
    width: auto;
    height: 42px;
    background: #ffffff;
    float: left;
    margin: 20px 0 0 20px;
    border: 2px solid #065F44;
    border-radius: 25px;
    padding: 0 3%;
    justify-content: center;
    align-items: center;
    font-size: 1.4rem;
    font-weight: bold;
}

#category ul li img{
    margin: 0 -10px 3px 10px;
}
#category ul li img.cate{
    margin: 0 -10px 0 -10px;
}
div.list{
    /* display: flex; */
    width: 90%;
    margin: 0 auto;
    height: 900px;
}

.list >ul{
    margin-top: 140px; 
    width: 100%;
    min-width: 0;
}
.list> ul> li{
    border-top: 1px solid #afafaf;
    padding: 40px 0;
    display: flex;
    height: 210px;
    width: 100%;
    font-size: 1.25em;
        line-height: 1.3;
        min-width: 0;
        text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  margin-left: -30px;

}
div.list> ul> li>img{
    width: 125px;
    height: 125px;
}
.list> ul> li:last-child{
    border-bottom: 1px solid #afafaf;
}

.list> ul> li> a{
    /* overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap; */
margin-left: 50px;
    width: 90%;
}
.list> ul> li>a >ul> li{
        
    margin-left: -30px;
    }


@media screen and (max-width:509px){
    #wrap{
        width: 100%;
        height: 1500px;
        min-width: 380px;
 
    }
    header{
            position: fixed;
    z-index: 10; 
    }
    iframe{
         height: 600px;
    }
    span.search{
        position: absolute;
         top: 90px;
        height: 35px;
        font-size: 1.05rem;
         position: absolute; left: 50%; transform: translateX(-50%); 
    }
    span.search img{
        padding-top: 2px;
        width: 15px;
    }
    
    #category{
        top: 574px;
            height: 1220px;
    }
    #category> ul>li{
        font-size: 1rem;
        height: 37px;
    }
    .list> ul> li{
        width: 108%;
        font-size: 1rem;
        padding: 30px 0 10px 0;
        height: 170px;

    }

    .list> ul> li >img.cafe{
        width: 90px;
    height: 90px;
    }

}
</style>